/* ══════════════════════════════════════════════════════════
   LEXORA — Main Script
══════════════════════════════════════════════════════════ */

// ── Particles ────────────────────────────────────────────
function createParticles(containerId) {
  const container = document.getElementById(containerId);
  if (!container) return;

  const particles = [];
  for (let i = 0; i < 25; i++) {
    const p = document.createElement('div');
    const size = Math.random() * 4 + 2;
    const left = Math.random() * 100;
    const duration = Math.random() * 8 + 6;
    const delay = Math.random() * 5;
    const hue = Math.random() > 0.5 ? '42' : '175';

    p.style.cssText = `
      position: absolute;
      width: ${size}px;
      height: ${size}px;
      background: hsl(${hue}, 80%, 65%);
      border-radius: 50%;
      left: ${left}%;
      bottom: -10px;
      opacity: 0;
      pointer-events: none;
      animation: float-particle ${duration}s ${delay}s ease-in-out infinite;
      box-shadow: 0 0 ${size * 2}px hsl(${hue}, 80%, 65%);
    `;
    container.appendChild(p);
    particles.push(p);
  }
  return particles;
}

// ── Splash page ───────────────────────────────────────────
const splashParticles = createParticles('splash-particles');

function enterWorld(e) {
  const splash = document.getElementById('splash-page');
  const homePage = document.getElementById('home-page');
  const splashImg = document.getElementById('splash-img');
  const splashCta = document.getElementById('splash-cta');

  // Magic burst effect
  const burst = document.createElement('div');
  burst.className = 'magic-burst';
  burst.style.left = e.clientX + 'px';
  burst.style.top = e.clientY + 'px';

  const core = document.createElement('div');
  core.className = 'magic-burst-core';
  burst.appendChild(core);

  const inner = document.createElement('div');
  inner.className = 'magic-burst-inner';
  const innerGlow = document.createElement('div');
  inner.appendChild(innerGlow);
  burst.appendChild(inner);

  // Sparkle rays
  for (let i = 0; i < 8; i++) {
    const ray = document.createElement('div');
    ray.className = 'sparkle-ray';
    ray.style.height = (80 + i * 20) + 'px';
    ray.style.transform = `translate(-50%, -50%) rotate(${i * 45}deg)`;
    ray.style.animationDelay = (i * 0.05) + 's';
    burst.appendChild(ray);
  }

  splash.appendChild(burst);

  // Fade out splash
  splashImg.style.transition = 'transform 1s ease, opacity 1s ease';
  splashImg.style.transform = 'scale(1.25)';
  splashImg.style.opacity = '0';
  splashCta.style.opacity = '0';
  splashCta.style.transform = 'translateY(40px)';

  setTimeout(() => {
    splash.style.display = 'none';
    homePage.classList.add('active');
    // Start hero particles
    createParticles('hero-particles');
    // Init scroll observers
    initScrollObservers();
  }, 1200);
}

// ── Mobile nav ────────────────────────────────────────────
let mobileOpen = false;
function toggleMobile() {
  mobileOpen = !mobileOpen;
  const menu = document.getElementById('mobile-menu');
  const menuIcon = document.getElementById('menu-icon');
  const closeIcon = document.getElementById('close-icon');

  if (mobileOpen) {
    menu.classList.add('open');
    menuIcon.style.display = 'none';
    closeIcon.style.display = 'block';
  } else {
    menu.classList.remove('open');
    menuIcon.style.display = 'block';
    closeIcon.style.display = 'none';
  }
}

function closeMobile() {
  mobileOpen = false;
  const menu = document.getElementById('mobile-menu');
  const menuIcon = document.getElementById('menu-icon');
  const closeIcon = document.getElementById('close-icon');
  menu.classList.remove('open');
  menuIcon.style.display = 'block';
  closeIcon.style.display = 'none';
}

// ── Scroll reveal ─────────────────────────────────────────
function initScrollObservers() {
  const revealEls = document.querySelectorAll('.reveal');
  const revealXEls = document.querySelectorAll('.reveal-x');

  const observer = new IntersectionObserver((entries) => {
    entries.forEach((entry, i) => {
      if (entry.isIntersecting) {
        entry.target.classList.add('visible');
        observer.unobserve(entry.target);
      }
    });
  }, { threshold: 0.15 });

  revealEls.forEach(el => observer.observe(el));
  revealXEls.forEach(el => observer.observe(el));
}

// ── Check if already visited (skip splash) ───────────────
window.addEventListener('DOMContentLoaded', () => {
  const entered = sessionStorage.getItem('lexora-entered');
  if (entered) {
    document.getElementById('splash-page').style.display = 'none';
    document.getElementById('home-page').classList.add('active');
    createParticles('hero-particles');
    initScrollObservers();
  }
  // Store session on next click too
  document.getElementById('splash-page')?.addEventListener('click', () => {
    sessionStorage.setItem('lexora-entered', 'true');
  });
});
